https://docs.google.com/document/d/1YCI3_Ps_Q9Cnpsg0XJLLgOKV6_WcIEg5UbHlxeaW-mY/ : Game Spec
